const cors = { 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok',{headers:cors});
  try {
    const lead = await req.json();
    const key = Deno.env.get('RESEND_API_KEY');
    const to = Deno.env.get('NOTIFY_TO_EMAIL') || 'nokhwalpankaj99@gmail.com';
    if (!key) throw new Error('RESEND_API_KEY is not configured');
    const html = `<h2>New Website Enquiry - Shanvi Insurance Services</h2>
      <p><b>Name:</b> ${esc(lead.name)}</p><p><b>Mobile:</b> ${esc(lead.mobile)}</p>
      <p><b>Email:</b> ${esc(lead.email || '-')}</p><p><b>Insurance:</b> ${esc(lead.insurance_type || '-')}</p>
      <pre style="font-family:Arial;white-space:pre-wrap">${esc(lead.message || '')}</pre>`;
    const r = await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({from:Deno.env.get('RESEND_FROM') || 'Shanvi Website <onboarding@resend.dev>',to:[to],subject:`New Enquiry: ${lead.name || 'Website'}`,html})});
    if(!r.ok) throw new Error(await r.text());
    return new Response(JSON.stringify({ok:true}),{headers:cors});
  } catch(e) { return new Response(JSON.stringify({ok:false,error:String(e.message||e)}),{status:500,headers:cors}); }
});
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
