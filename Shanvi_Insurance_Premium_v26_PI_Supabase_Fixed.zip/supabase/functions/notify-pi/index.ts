const cors = { 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok',{headers:cors});
  try {
    const data = await req.json();
    const key = Deno.env.get('RESEND_API_KEY');
    const to = Deno.env.get('NOTIFY_TO_EMAIL') || 'nokhwalpankaj99@gmail.com';
    const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const url = Deno.env.get('SUPABASE_URL');
    if (!key || !service || !url) throw new Error('Email/storage secrets are not configured');
    const links=[];
    for(const path of Object.values(data.files||{}).flat(Infinity)){
      if(typeof path!=='string' || !path.startsWith('INSURANCE/')) continue;
      const objectPath=path.replace(/^INSURANCE\//,'');
      const r=await fetch(`${url}/storage/v1/object/sign/INSURANCE/${encodeURIComponent(objectPath)}`,{method:'POST',headers:{Authorization:`Bearer ${service}`,'Content-Type':'application/json'},body:JSON.stringify({expiresIn:604800})});
      if(r.ok){const j=await r.json(); if(j.signedURL) links.push(`${path.split('/').slice(-1)[0]}: ${url}/storage/v1${j.signedURL}`)}
    }
    const html=`<h2>New PI / Inspection Request</h2><p><b>Request ID:</b> ${esc(data.id)}</p><p><b>Name:</b> ${esc(data.name)}</p><p><b>Email:</b> ${esc(data.email)}</p><p><b>Mobile:</b> ${esc(data.mobile)}</p><p><b>Vehicle:</b> ${esc(data.vehicle)}</p><p><b>UTR:</b> ${esc(data.utr)}</p><p><b>Video link:</b> ${esc(data.video_link || '-')}</p><h3>Secure document links (7 days)</h3><ul>${links.map(x=>`<li><a href="${esc(x.split(': ').slice(1).join(': '))}">${esc(x.split(': ')[0])}</a></li>`).join('')}</ul>`;
    const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({from:Deno.env.get('RESEND_FROM') || 'Shanvi Website <onboarding@resend.dev>',to:[to],subject:`New PI Request ${data.id} - ${data.vehicle}`,html})});
    if(!r.ok) throw new Error(await r.text());
    return new Response(JSON.stringify({ok:true}),{headers:cors});
  } catch(e){return new Response(JSON.stringify({ok:false,error:String(e.message||e)}),{status:500,headers:cors});}
});
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
